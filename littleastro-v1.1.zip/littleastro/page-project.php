<?php
/*
	Template Name: Project Page
 *
 * @link https://www.littleastro.net
 *
 * @package Little_Astronaut
 */

get_header(); ?>
<section class="project-page"> <!--MAIN ABOUT WITH PHOTO SECTION -->
	<div class="container clearfix">
	 <div class="row">
		<div class="col-md-12"> <!--- project description -->
	<?php
	while ( have_posts() ) : the_post();

		get_template_part( 'template-parts/content', 'page' );

	endwhile; // End of the loop.
	?>
</div>
</div>
</div>

	<?php if( have_rows('project_listing_rpt') ): ?>

	<?php while( have_rows('project_listing_rpt') ): the_row();

	// ADVANCED CUSTOM FIELDS vars
	$project_title = get_sub_field('project_title');
	$project_description = get_sub_field('project_description');
	$project_image = get_sub_field('project_image');
	$external_url_link = get_sub_field('external_url_link');

	?>

	<div class = "project-left">
		<div class="container clearfix">
		<div class="row">
				<div class="col-md-5"><!---project img-->
				<img class="project-img" src="<?php echo $project_image['url'];?>">
			</div>
			<div class="col-md-7"> <!--- project description -->
				<h2><?php echo $project_title; ?></h2>
				<p><?php echo $project_description; ?></p>
				</div>
		</div>
		</div>
	</div>

<?php endwhile; ?>

<?php endif; ?>
</section><!--Project SECTION -->


<?php get_footer(); ?>
