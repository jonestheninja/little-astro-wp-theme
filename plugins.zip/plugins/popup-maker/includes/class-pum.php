<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PUM {

	const VER = '1.6.6';

	const DB_VER = 6;

	const API_URL = 'https://wppopupmaker.com/?edd_action=';

}
